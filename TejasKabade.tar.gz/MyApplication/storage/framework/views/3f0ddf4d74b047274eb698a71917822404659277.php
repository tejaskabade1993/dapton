<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <title>Laravel</title>

      <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.js"></script>

      <!-- Styles -->
      <style type="text/css">
        #success_message{ display: none;}
        .formcss{
          width: 70%;
          margin-right: auto;
          margin-left: auto;margin-top: 5%;
        }
      </style>
  </head>
  <body>

    <div class="container">
      
      
      <form class="well form-horizontal formcss" action=" " method="post" id="firstForm" >
          <center>
            <button class="btn btn-warning">
                <a style="color: #fff;" href="<?php echo e(url('employeeDetails')); ?>">See All Employee List</a> <span class="glyphicon glyphicon-home"></span>
           </button>
          </center>
        <fieldset>
          <legend><center><h2><b>Employee Detail Form</b></h2></center></legend><br>
          <div class="form-group">
            <label class="col-md-4 control-label">First Name</label>  
            <div class="col-md-6 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input  name="first_name" placeholder="First Name" id="first_name" class="form-control"  type="text">
            </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" >Last Name</label> 
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="last_name" name="last_name" placeholder="Last Name" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label">E-Mail</label>  
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                  <input id="email" name="email" placeholder="E-Mail Address" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label">Contact No.</label>  
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                  <input id="phone" name="phone" placeholder="Contact No" class="form-control" type="text">
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <div class="col-md-12"><br>
              <center>
                <button type="submit" id="nextBt" class="btn btn-success" >SUBMIT <span class="glyphicon glyphicon-arrow-right"></span>
             </button>
              </center>
             
            </div>
          </div>
        </fieldset>
      </form>

        <div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

      <form class="well form-horizontal formcss" action=" " method="post"  id="secondForm">
        <fieldset>
          <input type="hidden" name="id" id="employee_id" value="" >
          <div class="form-group">
            <label class="col-md-4 control-label">Birth Date</label>  
            <div class="col-md-6 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input  name="birth_date" placeholder="Birth Date" id="birth_date" class="form-control"  type="date">
            </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" >Salary</label> 
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="salary" name="salary" placeholder="Salary" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-md-12"><br>
              <center>
                <button type="submit" class="btn btn-success" >SAVE <span class="glyphicon glyphicon-send"></span>
             </button>
              </center>
             
            </div>
          </div>
        </fieldset>

      </form>
    </div>
   
   </body>
</html>
<script type="text/javascript">
  $(document).ready(function() {
      $('#secondForm').addClass('hide');
      $('#firstForm').bootstrapValidator({
              feedbackIcons: {
                  valid: 'glyphicon glyphicon-ok',
                  invalid: 'glyphicon glyphicon-remove',
                  validating: 'glyphicon glyphicon-refresh'
              },
              fields: {
                        first_name: {
                            validators: {
                                    stringLength: {
                                    min: 2,
                                },
                                    notEmpty: {
                                    message: 'Please enter your First Name'
                                }
                            }
                        },
                         last_name: {
                            validators: {
                                 stringLength: {
                                    min: 2,
                                },
                                notEmpty: {
                                    message: 'Please enter your Last Name'
                                }
                            }
                        },
                        email: {
                              validators: {
                                  notEmpty: {
                                      message: 'Please enter your Email Address'
                                  },
                                  emailAddress: {
                                      message: 'Please enter a valid Email Address'
                                  }
                              }
                          },
                         phone: {
                              validators: {
                                  notEmpty: {
                                      message: 'Please enter your Phone'
                                  }
                              }
                          },  
                   
                  }
            })
            .on('success.form.bv', function(e) {
                $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#firstForm').data('bootstrapValidator').resetForm();
                e.preventDefault();
                var $form = $(e.target);
                var bv = $form.data('bootstrapValidator');

                first_name = $('#first_name').val();
                last_name = $('#last_name').val();
                email = $('#email').val();
                phone = $('#phone').val();

               $.ajax({
                        url: "/employees",
                        type:"POST",
                        data:{
                          "_token": "<?php echo e(csrf_token()); ?>",
                          first_name:first_name,
                          last_name:last_name,
                          email:email,
                          phone:phone,
                       },
                  success:function(response){

                    console.log(response.last_insert_id);
                    $('#secondForm').removeClass('hide');
                    $('#firstForm').addClass('hide');

                    $('#employee_id').val(response.last_insert_id);
                  },
                 });
            });


      $('#secondForm').bootstrapValidator({
              feedbackIcons: {
                  valid: 'glyphicon glyphicon-ok',
                  invalid: 'glyphicon glyphicon-remove',
                  validating: 'glyphicon glyphicon-refresh'
              },
              fields: {
                        birth_date: {
                            validators: {
                                    stringLength: {
                                    min: 2,
                                },
                                    notEmpty: {
                                    message: 'Please enter your Birth Date'
                                }
                            }
                        },
                         salary: {
                            validators: {
                                 stringLength: {
                                    min: 2,
                                },
                                notEmpty: {
                                    message: 'Please enter your Salary'
                                }
                            }
                        },
                        
                   
                  }
            })
            .on('success.form.bv', function(e) {
              $('#success_message').addClass('hide');
                //$('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#secondForm').data('bootstrapValidator').resetForm();
                e.preventDefault();
                var $form = $(e.target);
                var bv = $form.data('bootstrapValidator');
                
                employee_id = $('#employee_id').val(); 
                birth_date = $('#birth_date').val();
                salary = $('#salary').val();


                $.ajax({
                  url: "/updateEmployees",
                  type:"POST",
                  data:{
                    "_token": "<?php echo e(csrf_token()); ?>",
                     id:employee_id, 
                     birth_date:birth_date,
                     salary:salary,
                  },
                  success:function(response){
                    $('#success_message').removeClass('hide');

                      console.log(response);
                      callEmpfun();
                  },
                 });
            });

    function callEmpfun(){
        $.ajax({
                  url: "/employeeDetails",
                  type:"POST",
                  data:{
                    "_token": "<?php echo e(csrf_token()); ?>",
                  },
                  success:function(response){
                    $('#success_message').removeClass('hide');
                    $(".container").empty();           
                    $(".container").html(response);
                      
                  },
                 });
    }        


  });
      

    

</script><?php /**PATH /var/www/html/MyApplication/resources/views/welcome.blade.php ENDPATH**/ ?>