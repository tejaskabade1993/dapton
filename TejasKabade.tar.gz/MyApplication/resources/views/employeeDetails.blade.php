
<?php 
  $EmpArray = json_decode(json_encode($employees), true); ?>
<head>
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.js"></script>
      <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
      
</head>
<div id="empdetails" class="well">
  <h3>All Employee Details</h3>
    <div class="table-responsive">
      <table id="EmpDetailtbl" class="table table-condensed table-hover table-bordered">
          <thead>
            <tr>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">Birt Date</th>
              <th scope="col">Salary</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
                @foreach ($EmpArray as $key=> $employee)
                 <tr>
                  <td><?php echo $employee['first_name']; ?></td>
                  <td><?php echo $employee['last_name']; ?></td>
                  <td><?php echo $employee['email']; ?></td>
                  <td><?php echo $employee['phone']; ?></td> 
                  <td><?php echo $employee['birth_date']; ?></td>
                  <td><?php echo $employee['salary']; ?></td>
                  <td>
                    <button class="btn mr-2 mb-2 btn-info" id="editOrder" onclick="editEmployee('<?php echo $employee['id'];?>')" name="">Edit
                      <span class="glyphicon glyphicon-edit"></span>
                    </button>
                    <button class="btn mr-2 mb-2 btn-danger" id="deleteEmployee" onclick="deleteEmployee('<?php echo $employee['id'];?>')">Delete
                      <span class="glyphicon glyphicon-trash"></span>
                    </button>
                  </td>
                </tr>
                @endforeach 
          </tbody>
      </table>
    </div>
</div>

<script type="text/javascript">
      
  function editEmployee(id){
    //alert(id);
     $.ajax({
                  url: "/editEmployees",
                  type:"POST",
                  data:{
                    "_token": "{{ csrf_token() }}",
                    id:id,
                   },
            success:function(response){

              console.log(response);
              $("#empdetails").empty();           
              $("#empdetails").html(response)
            },
           });
  }

  function deleteEmployee(id){
    //alert(id);
     $.ajax({
                  url: "/deleteEmployees",
                  type:"POST",
                  data:{
                    "_token": "{{ csrf_token() }}",
                    id:id,
                   },
            success:function(response){

              console.log(response);
              $("#empdetails").empty();           
              $("#empdetails").html(response)
            },
           });
  }
    
</script>
   