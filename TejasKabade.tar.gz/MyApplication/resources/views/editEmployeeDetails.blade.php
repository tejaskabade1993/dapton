 <?php $editEmployee = json_decode(json_encode($editEmployeeDetails), true); ?>
      <div class="alert alert-warning" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>
      
      <center>
            <button class="btn btn-warning">
                <a style="color: #fff;" href="{{ url('employeeDetails') }}">See All Employee List</a> <span class="glyphicon glyphicon-home"></span>
            </button>
      </center>
      <form class="well form-horizontal formcss" action=" " method="post" id="EmpEditForm" >
          <input type="hidden" name="id" id="employee_id" value="<?php echo $editEmployee[0]['id']; ?>" >
        <fieldset>
          <legend><center><h2><b>Employee Detail Form</b></h2></center></legend><br>
          <div class="form-group">
            <label class="col-md-4 control-label">First Name</label>  
            <div class="col-md-6 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input  name="first_name" placeholder="First Name" id="first_name" class="form-control" value="<?php echo $editEmployee[0]['first_name']; ?>" type="text">
            </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" >Last Name</label> 
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="last_name" name="last_name" placeholder="Last Name"  value="<?php echo $editEmployee[0]['last_name'];?>" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label">E-Mail</label>  
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                  <input id="email" name="email" placeholder="E-Mail Address"  value="<?php echo $editEmployee[0]['email'];?>" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label">Contact No.</label>  
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                  <input id="phone" name="phone" placeholder="Contact No"  value="<?php echo $editEmployee[0]['phone'];?>" class="form-control" type="text">
              </div>
            </div>
          </div>
         
           <input  name="birth_date" placeholder="Birth Date" id="birth_date"  value="<?php echo $editEmployee[0]['birth_date'];?>" class="form-control"  type="hidden">

          <div class="form-group">
            <label class="col-md-4 control-label" >Salary</label> 
              <div class="col-md-6 inputGroupContainer">
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="salary" name="salary" placeholder="Last Name"  value="<?php echo $editEmployee[0]['salary'];?>" class="form-control"  type="text">
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-md-12"><br>
              <center>
                <button type="submit" class="btn btn-success" >SUBMIT <span class="glyphicon glyphicon-send"></span>
             </button>
              </center>
             
            </div>
          </div>
        </fieldset>

      </form>
   <script type="text/javascript">
    $('#success_message').addClass('hide');
       $('#EmpEditForm').bootstrapValidator({
              feedbackIcons: {
                  valid: 'glyphicon glyphicon-ok',
                  invalid: 'glyphicon glyphicon-remove',
                  validating: 'glyphicon glyphicon-refresh'
              },
              fields: {
                        first_name: {
                            validators: {
                                    stringLength: {
                                    min: 2,
                                },
                                    notEmpty: {
                                    message: 'Please enter your First Name'
                                }
                            }
                        },
                         last_name: {
                            validators: {
                                 stringLength: {
                                    min: 2,
                                },
                                notEmpty: {
                                    message: 'Please enter your Last Name'
                                }
                            }
                        },
                        email: {
                              validators: {
                                  notEmpty: {
                                      message: 'Please enter your Email Address'
                                  },
                                  emailAddress: {
                                      message: 'Please enter a valid Email Address'
                                  }
                              }
                          },
                          
                         
                          salary: {
                              validators: {
                                  stringLength: {
                                      message: 'Please enter your Salary'
                                  },
                                  notEmpty: {
                                      message: 'Please enter a valid Salary'
                                  }
                              }
                          },
                          phone: {
                            validators: {
                                    stringLength: {
                                    min: 2,
                                },
                                    notEmpty: {
                                    message: 'Please enter your phone'
                                }
                            }
                        },

                   
                  }
            })
            .on('success.form.bv', function(e) {
                $('#success_message').slideDown({ opacity: "show" }, "slow") 
                $('#EmpEditForm').data('bootstrapValidator').resetForm();
                e.preventDefault();
                var $form = $(e.target);
                var bv = $form.data('bootstrapValidator');

                id = $('#employee_id').val();
                first_name = $('#first_name').val();
                last_name = $('#last_name').val();
                email = $('#email').val();
                phone = $('#phone').val();
                birth_date = $('#birth_date').val();
                salary = $('#salary').val();
                

               $.ajax({
                        url: "/saveEditEmpDetails",
                        type:"POST",
                        data:{
                          "_token": "{{ csrf_token() }}",
                          id:id,
                          first_name:first_name,
                          last_name:last_name,
                          email:email,
                          phone:phone,
                          birth_date:birth_date,
                          salary:salary,
                       },
                  success:function(response){
                    $('#success_message').removeClass('hide');
                    //console.log(response);
                    
                  },
                 });
            });
   </script>