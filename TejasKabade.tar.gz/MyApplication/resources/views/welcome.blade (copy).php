<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="row">
             <div class="col-sm-8 offset-sm-2">
                <h3>Add a employee</h3>
              <div>
                @if ($errors->any())
                  <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                  </div><br />
                @endif
                  <form id="formCreateEmployee" method="post" action="">
                      @csrf
                      <div class="form-group">    
                          <label for="first_name">First Name:</label>
                          <input type="text" class="form-control" id="first_name" name="first_name"/>
                      </div>

                      <div class="form-group">
                          <label for="last_name">Last Name:</label>
                          <input type="text" class="form-control" id="last_name" name="last_name"/>
                      </div>

                      <div class="form-group">
                          <label for="email">Email:</label>
                          <input type="text" class="form-control" id="email" name="email"/>
                      </div>
                      <div class="form-group">
                          <label for="city">Phone:</label>
                          <input type="text" class="form-control" id="phone" name="phone"/>
                      </div>
                      <div class="form-group">
                          <label for="country">Birth date:</label>
                          <input type="text" class="form-control" id="birth_date" name="birth_date"/>
                      </div>
                      <div class="form-group">
                          <label for="job_title">Salary:</label>
                          <input type="text" class="form-control" id="salary" name="salary"/>
                      </div>                         
                      <!-- <input type="button" class="btn btn-primary" id="btnCreateEmployee" name="" value="Create" /> -->
                      <button type="submit">Create</button>  
                  </form>
              </div>
            </div>
            </div>
           
    </body>
</html>
<script type="text/javascript">
    

    $('#formCreateEmployee').on('submit',function(event){
        event.preventDefault();

        first_name = $('#first_name').val();
        last_name = $('#last_name').val();
        email = $('#email').val();
        phone = $('#phone').val();
        birth_date = $('#birth_date').val();
        salary = $('#salary').val();

        $.ajax({
          url: "/employees",
          type:"POST",
          data:{
            "_token": "{{ csrf_token() }}",
            first_name:first_name,
            last_name:last_name,
            email:email,
            phone:phone,
            birth_date:birth_date,
            salary:salary,
          },
          success:function(response){
            console.log(response);
          },
         });
        });
</script>